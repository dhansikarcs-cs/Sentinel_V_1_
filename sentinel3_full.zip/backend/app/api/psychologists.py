from datetime import UTC, datetime

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.dependencies import require_role
from app.events import get_event_bus
from app.models.clinical_note import ClinicalNote
from app.models.user import User
from app.repositories import PatientRepository

router = APIRouter(prefix="/psychologists", tags=["psychologists"])


@router.get("/patients")
def get_assigned_patients(user: User = Depends(require_role("psychologist")), db: Session = Depends(get_db)):
    repo = PatientRepository(db)
    patients = repo.get_assigned_patients(user.username)
    return [
        {
            "username": p.username,
            "name": p.name,
            "age": p.age,
            "occupation": p.occupation,
            "clinic": p.clinic_code or "",
            "onboarding_step": p.onboarding_step or 0,
        }
        for p in patients
    ]


@router.get("/available")
def get_available_psychologists(clinic: str = "", db: Session = Depends(get_db)):
    repo = PatientRepository(db)
    return [{"username": p.username, "name": p.name} for p in repo.get_psychologists(clinic)]


@router.post("/notes")
def save_clinical_note(
    patient_username: str,
    raw_notes: str,
    approved: bool = False,
    user: User = Depends(require_role("psychologist")),
    db: Session = Depends(get_db),
):
    now = datetime.now(UTC).isoformat()
    note = ClinicalNote(
        psychologist_username=user.username,
        patient_username=patient_username,
        raw_notes=raw_notes,
        ai_synthesis=raw_notes,
        timestamp=now,
        approved_by=user.username if approved else "",
        approved_at=now if approved else "",
    )
    db.add(note)
    db.commit()
    get_event_bus().emit(
        "clinical_note:saved",
        psych=user.username,
        patient_username=patient_username,
        approved=approved,
    )
    return {"message": "Saved", "id": note.id}


@router.put("/notes/{note_id}/approve")
def approve_clinical_note(
    note_id: int, user: User = Depends(require_role("psychologist")), db: Session = Depends(get_db)
):
    note = db.query(ClinicalNote).filter(ClinicalNote.id == note_id).first()
    if not note:
        return {"error": "Not found"}
    now = datetime.now(UTC).isoformat()
    note.approved_by = user.username
    note.approved_at = now
    db.commit()
    get_event_bus().emit("clinical_note:approved", psych=user.username, note_id=note_id)
    return {"message": "Approved", "id": note_id}


@router.get("/notes")
def get_clinical_notes(
    patient: str = "", user: User = Depends(require_role("psychologist")), db: Session = Depends(get_db)
):
    query = db.query(ClinicalNote).filter(ClinicalNote.psychologist_username == user.username)
    if patient:
        query = query.filter(ClinicalNote.patient_username == patient)
    notes = query.order_by(ClinicalNote.timestamp.desc()).limit(50).all()
    return [
        {
            "id": n.id,
            "patient": n.patient_username,
            "ai_synthesis": n.ai_synthesis,
            "timestamp": n.timestamp,
            "approved_by": n.approved_by,
            "approved_at": n.approved_at,
        }
        for n in notes
    ]
