from typing import Literal

from pydantic import BaseModel, Field


class FollowupCreate(BaseModel):
    patient_username: str = Field(min_length=1, max_length=50)
    title: str = Field(min_length=1, max_length=200)
    description: str = Field(default="", max_length=5000)
    file_path: str = Field(default="", max_length=500)
    due_date: str = Field(default="", max_length=10)


class FollowupUpdate(BaseModel):
    status: Literal["pending", "completed", "skipped"] = "pending"
    grade: Literal["none", "red", "yellow", "green"] = "none"
    file_path: str = Field(default="", max_length=500)


class FollowupResponse(BaseModel):
    id: str
    patient_username: str
    psychologist_username: str
    title: str
    description: str
    file_path: str = ""
    status: str
    grade: str
    assigned_at: str
    due_date: str = ""
    completed_at: str = ""
    approved_by: str = ""
    approved_at: str = ""

    class Config:
        from_attributes = True
